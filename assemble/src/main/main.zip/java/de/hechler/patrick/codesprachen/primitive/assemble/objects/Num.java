package de.hechler.patrick.codesprachen.primitive.assemble.objects;

import java.util.Arrays;

public class Num {
	
	private final long[] nums;
	private final int[] art;
	
	private Num(long[] nums, int[] arts) {
		this.nums = nums;
		this.art = arts;
	}
	
	public static Num createConstAX() {
		return new Num(new long[] {0 }, new int[] {1 });
	}
	
	public static Num createConstBX() {
		return new Num(new long[] {0 }, new int[] {2 });
	}
	
	public static Num createConstCX() {
		return new Num(new long[] {0 }, new int[] {3 });
	}
	
	public static Num createConstDX() {
		return new Num(new long[] {0 }, new int[] {4 });
	}
	
	public static Num createConstNum(long num) {
		return new Num(new long[] {num }, new int[] {0 });
	}
	
	public static Num createRegNumoff(Num base, long off) {
		long[] nums = Arrays.copyOf(base.nums, base.nums.length + 1);
		nums[nums.length - 1] = off;
		int[] arts = Arrays.copyOf(base.art, nums.length);
		arts[arts.length - 1] = 0;
		return new Num(nums, arts);
	}
	
	public static Num createRegAXOff(Num base) {
		long[] nums = Arrays.copyOf(base.nums, base.nums.length + 1);
		nums[nums.length - 1] = 0;
		int[] arts = Arrays.copyOf(base.art, nums.length);
		arts[arts.length - 1] = 1;
		return new Num(nums, arts);
	}
	
	public static Num createRegBXOff(Num base) {
		long[] nums = Arrays.copyOf(base.nums, base.nums.length + 1);
		nums[nums.length - 1] = 0;
		int[] arts = Arrays.copyOf(base.art, nums.length);
		arts[arts.length - 1] = 2;
		return new Num(nums, arts);
	}
	
	public static Num createRegCXOff(Num base) {
		long[] nums = Arrays.copyOf(base.nums, base.nums.length + 1);
		nums[nums.length - 1] = 0;
		int[] arts = Arrays.copyOf(base.art, nums.length);
		arts[arts.length - 1] = 3;
		return new Num(nums, arts);
	}
	
	public static Num createRegDXOff(Num base) {
		long[] nums = Arrays.copyOf(base.nums, base.nums.length + 1);
		nums[nums.length - 1] = 0;
		int[] arts = Arrays.copyOf(base.art, nums.length);
		arts[arts.length - 1] = 4;
		return new Num(nums, arts);
	}
	
	public int deep() {
		return nums.length - 1;
	}
	
	public long num(int i) {
		if (art[i] != 0) {
			throw new IllegalStateException("art[" + i + "] is no num!");
		}
		return nums[i];
	}
	
	public int sr(int i) {
		if (art[i] == 0) {
			throw new IllegalStateException("art[" + i + "] is no sr!");
		}
		return art[i] - 1;
	}
	
	public boolean isNum(int i) {
		return art[i] == 0;
	}

}
