package de.hechler.patrick.codesprachen.primitive.assemble.objects;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import de.hechler.patrick.antlr.v4.codespr.primitive.PrimGrammarParser.DateiContext;
import de.hechler.patrick.codesprachen.primitive.assemble.enums.Commands;
import de.hechler.patrick.codesprachen.primitive.assemble.objects.commands.Command;

public class PrimitiveAssembler {
	
	private OutputStream out;
	
	
	public PrimitiveAssembler(OutputStream out) {
		this.out = out;
	}
	
	
	public void compile(DateiContext datei) throws IOException {
		Map <String, Long> labels = new HashMap <>();
		long len = 0;
		Command[] cmds = datei.cmds.toArray(new Command[0]);
		long[] pos = new long[cmds.length];
		for (int i = 0; i < cmds.length; i ++ ) {
			if (cmds[i].art == Commands.LABEL) {
				labels.put(cmds[i].params.get(0).getConstStr(), len);
			} else {
				len += cmds[i].art.length(cmds[i]);
			}
			pos[i] = len;
		}
		for (int i = 0; i < cmds.length; i ++ ) {
			if (cmds[i].art == Commands.LABEL) {
				continue;
			}
			byte[] bytes = cmds[i].art.bytes(pos, cmds, i, labels);
			out.write(bytes);
		}
		out.flush();
	}
	
}
