package de.hechler.patrick.codesprachen.primitive.assemble.objects.commands;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import de.hechler.patrick.codesprachen.primitive.assemble.enums.Commands;
import de.hechler.patrick.codesprachen.primitive.assemble.objects.Num;

public class Command {
	
	public final Commands art;
	public final List <Num> params;
	
	
	
	public Command(Commands art, Num... params) {
		this.art = art;
		this.params = Collections.unmodifiableList(Arrays.asList(params.clone()));
	}
	
	public Command(Commands art, List <Num> params) {
		this.art = art;
		this.params = Collections.unmodifiableList(new ArrayList <>(params));
	}
	
}
