package de.hechler.patrick.codesprachen.primitive.assemble.enums;

import java.util.Map;

import de.hechler.patrick.codesprachen.primitive.assemble.objects.Num;
import de.hechler.patrick.codesprachen.primitive.assemble.objects.commands.Command;

public enum Commands {
	
	MOV(0x01, 8, 2),
	
	ADD(0x02, 8, 2), SUB(0x03, 8, 2), MUL(0x04, 8, 2), DIV(0x05, 8, 2),
	
	NEG(0x06, 8, 1),
	
	
	AND(0x07, 8, 2), OR(0x08, 8, 2), XOR(0x09, 8, 2),
	
	NOT(0x0A, 8, 1),
	
	
	CMP(0x10, 8, 2),
	
	PUSH(0x11, 8, 2), POP(0x12, 8, 2), RET(0x13, 8, 1),
	
	EXIT(0x14, 8, 1),
	
	
	JMP(0x20, 16, 0), JMPEQ(0x21, 16, 0), JMPNE(0x22, 16, 0), JMPGT(0x23, 16, 0), JMPGE(0x24, 16, 0), JMPLO(0x25, 16, 0), JMPLE(0x26, 16, 0),
	
	CALL(0x27, 16, 0), CALLEQ(0x28, 16, 0), CALLNE(0x29, 16, 0), CALLGT(0x2A, 16, 0), CALLGE(0x2B, 16, 0), CALLLO(0x2C, 16, 0), CALLLE(0x2D, 16, 0),
	
	
	SJMP(0x30, 8, 0), SJMPEQ(0x31, 8, 0), SJMPNE(0x32, 8, 0), SJMPGT(0x33, 8, 0), SJMPGE(0x34, 8, 0), SJMPLO(0x35, 8, 0), SJMPLE(0x36, 8, 0),
	
	SCALL(0x37, 8, 0), SCALLEQ(0x38, 8, 0), SCALLNE(0x39, 8, 0), SCALLGT(0x3A, 8, 0), SCALLGE(0x3B, 8, 0), SCALLLO(0x3C, 8, 0), SCALLLE(0x3D, 8, 0),
	
	
	GET_INST_PNTR(0x40, 8, 1), GET_INST_CNT(0x41, 8, 1),
	
	GET_STACK_PNTR(0x42, 8, 1), GET_STACK_OVER_PNT(0x43, 8, 1),
	
	SET_INST_PNTR(0x44, 8, 1), SET_INST_CNT(0x45, 8, 1),
	
	SET_STACK_PNTR(0x46, 8, 1), SET_STACK_OVER_PNT(0x47, 8, 1),
	
	
	INT(0x50, 8, 0), IRET(0x51, 8, 0),
	
	SET_INT(0x52, 16, 0), GET_INT(0x53, 8, 1),
	
	
	
	CONSTANT_POOL( -1, 0, 0), LABEL( -1, 0, 0);
	
	
	
	public final int nummer;
	private final int baseLen;
	private final int nums;
	
	
	
	private Commands(int nummer, int baseLen, int nums) {
		this.nummer = nummer;
		this.baseLen = baseLen;
		this.nums = nums;
	}
	
	
	
	public byte[] bytes(long[] pos, Command[] cmds, int i, Map <String, Long> labels) {
		switch (this) {
		case MOV:
		case ADD:
		case SUB:
		case MUL:
		case AND:
		case OR:
		case XOR: {
			Num n1 = cmds[i].params.get(0).getNum();
			Num n2 = cmds[i].params.get(1).getNum();
			// byte[] bytes = new byte[8 + (n1.isNum() ? 8 : 0) + (n2.isNum() ? 8 : 0)];
			// bytes[0] = (byte) nummer;
			// return bytes;
		}
		case CALL:
		case CALLEQ:
		case CALLGE:
		case CALLGT:
		case CALLLE:
		case CALLLO:
		case CALLNE:
		case JMP:
		case JMPEQ:
		case JMPGE:
		case JMPGT:
		case JMPLE:
		case JMPLO:
		case JMPNE: {
			byte[] bytes = new byte[16];
			bytes[0] = (byte) nummer;
			long write = pos[i] - (long) labels.get(cmds[i].params.get(0).getConstStr());
			bytes[15] = (byte) write;
			bytes[14] = (byte) (write << 8);
			bytes[13] = (byte) (write << 16);
			bytes[12] = (byte) (write << 24);
			bytes[11] = (byte) (write << 32);
			bytes[10] = (byte) (write << 40);
			bytes[9] = (byte) (write << 48);
			bytes[8] = (byte) (write << 56);
			return bytes;
		}
		case SCALL:
		case SCALLEQ:
		case SCALLGE:
		case SCALLGT:
		case SCALLLE:
		case SCALLLO:
		case SCALLNE:
		case SJMP:
		case SJMPEQ:
		case SJMPGE:
		case SJMPGT:
		case SJMPLE:
		case SJMPLO:
		case SJMPNE: {
			byte[] bytes = new byte[8];
			bytes[0] = (byte) nummer;
			long write = pos[i] - (long) labels.get(cmds[i].params.get(0).getConstStr());
			bytes[1] = (byte) (write << 8);
			bytes[2] = (byte) (write << 16);
			bytes[3] = (byte) (write << 24);
			bytes[4] = (byte) (write << 32);
			bytes[5] = (byte) (write << 40);
			bytes[6] = (byte) (write << 48);
			bytes[7] = (byte) (write << 56);
			return bytes;
		}
		case CMP: {
			Num n1 = cmds[i].params.get(0).getNum();
			Num n2 = cmds[i].params.get(1).getNum();
			// byte[] bytes = new byte[8 + (n1.isNum() ? 8 : 0) + (n2.isNum() ? 8 : 0)];
			// bytes[0] = (byte) nummer;
			// return bytes;
		}
		case DIV: {
			Num n1 = cmds[i].params.get(0).getNum();
			Num n2 = cmds[i].params.get(1).getNum();
			// byte[] bytes = new byte[8 + (n1.isNum() ? 8 : 0) + (n2.isNum() ? 8 : 0)];
			// bytes[0] = (byte) nummer;
			// return bytes;
		}
		case SET_INST_PNTR:
		case SET_INST_CNT:
		case SET_STACK_OVER_PNT:
		case SET_STACK_PNTR:
		case PUSH:
		case EXIT: {
			Num n = cmds[i].params.get(0).getNum();
			// byte[] bytes = new byte[8 + (n.isNum() ? 8 : 0)];
			// bytes[0] = (byte) nummer;
			// return bytes;
		}
		case GET_INST_PNTR:
		case GET_INST_CNT:
		case GET_STACK_OVER_PNT:
		case GET_STACK_PNTR:
		case NEG:
		case NOT:
		case POP: {
			Num n = cmds[i].params.get(0).getNum();
			// byte[] bytes = new byte[8 + (n.isNum() ? 8 : 0)];
			// bytes[0] = (byte) nummer;
			// return bytes;
		}
		case LABEL:
			return null;
		case RET:
			byte[] bytes = new byte[8];
			bytes[0] = (byte) nummer;
			return bytes;
		}
		throw new InternalError("unknown Commands: " + name());
	}
	
	public int length(Command cmd) {
		int len = baseLen;
		for (int i = 0; i < nums; i ++ ) {
			// if (cmd.params.get(i).getNum().isNum()) {
			// len += 16;
			// } else {
			// len += 8;
			// }
		}
		return len;
	}
	
}
