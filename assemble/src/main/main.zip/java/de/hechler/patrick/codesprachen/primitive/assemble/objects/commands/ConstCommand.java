package de.hechler.patrick.codesprachen.primitive.assemble.objects.commands;

import java.util.Collections;

import de.hechler.patrick.codesprachen.primitive.assemble.enums.Commands;

public class ConstCommand extends Command {
	
	public final String pool;
	
	public ConstCommand(String pool) {
		super(Commands.CONSTANT_POOL, Collections.emptyList());
		this.pool = pool;
	}
	
}
