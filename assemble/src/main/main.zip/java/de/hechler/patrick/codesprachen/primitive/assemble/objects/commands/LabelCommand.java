package de.hechler.patrick.codesprachen.primitive.assemble.objects.commands;

import java.util.Collections;

import de.hechler.patrick.codesprachen.primitive.assemble.enums.Commands;

public class LabelCommand extends Command {
	
	public final String name;
	
	public LabelCommand(String name) {
		super(Commands.LABEL, Collections.emptyList());
		this.name = name;
	}
	
}
