package de.patrick.hechler.codesprachen.primitive.assemble.objects;

import java.util.Map;

import de.patrick.hechler.codesprachen.primitive.assemble.enums.Commands;

public class Param {
	
	private static final int ART_NUM = 1;
	private static final int ART_SR = 2;
	private static final int ART_REG_NUM = 3;
	private static final int ART_REG_SR = 4;
	private static final int ART_OFF_NUM = 5;
	private static final int ART_OFF_SR = 6;
	private static final int ART_REG_REG_NUM = 7;
	private static final int ART_REG_REG_SR = 8;
	private static final int ART_REG_OFF_NUM = 9;
	private static final int ART_REG_OFF_SR = 10;
	private static final int ART_OFF_REG_NUM = 11;
	private static final int ART_OFF_REG_SR = 12;
	private static final int ART_OFF_OFF_NUM = 13;
	private static final int ART_OFF_OFF_SR = 14;
	private static final Constant SR_AX = new Constant(1);
	private static final Constant SR_BX = new Constant(2);
	private static final Constant SR_CX = new Constant(3);
	private static final Constant SR_DX = new Constant(4);
	
	private final Constant val;
	private final Constant normalOff;
	private final Constant innerOff;
	private final int art;
	
	private Param(Constant val, Constant off0, Constant off1, int art) {
		this.val = val;
		this.normalOff = off0;
		this.innerOff = off1;
		this.art = art;
	}
	
	public static Param createNum(Constant val) {
		return new Param(val, null, null, ART_NUM);
	}
	
	public static Param createAX() {
		return new Param(SR_AX, null, null, ART_SR);
	}
	
	public static Param createBX() {
		return new Param(SR_BX, null, null, ART_SR);
	}
	
	public static Param createCX() {
		return new Param(SR_CX, null, null, ART_SR);
	}
	
	public static Param createDX() {
		return new Param(SR_DX, null, null, ART_SR);
	}
	
	public static Param createRegNum(Constant val) {
		return new Param(val, null, null, ART_REG_NUM);
	}
	
	public static Param createRegAX() {
		return new Param(SR_AX, null, null, ART_REG_SR);
	}
	
	public static Param createRegBX() {
		return new Param(SR_BX, null, null, ART_REG_SR);
	}
	
	public static Param createRegCX() {
		return new Param(SR_CX, null, null, ART_REG_SR);
	}
	
	public static Param createRegDX() {
		return new Param(SR_DX, null, null, ART_REG_SR);
	}
	
	public static Param createOffNum(Constant val, Constant off) {
		return new Param(val, off, null, ART_OFF_NUM);
	}
	
	public static Param createOffAX(Constant off) {
		return new Param(SR_AX, off, null, ART_OFF_SR);
	}
	
	public static Param createOffBX(Constant off) {
		return new Param(SR_BX, off, null, ART_OFF_SR);
	}
	
	public static Param createOffCX(Constant off) {
		return new Param(SR_CX, off, null, ART_OFF_SR);
	}
	
	public static Param createOffDX(Constant off) {
		return new Param(SR_DX, off, null, ART_OFF_SR);
	}
	
	public static Param createRegRegNum(Constant val) {
		return new Param(val, null, null, ART_REG_REG_NUM);
	}
	
	public static Param createRegRegAX() {
		return new Param(SR_AX, null, null, ART_REG_REG_SR);
	}
	
	public static Param createRegRegBX() {
		return new Param(SR_BX, null, null, ART_REG_REG_SR);
	}
	
	public static Param createRegRegCX() {
		return new Param(SR_CX, null, null, ART_REG_REG_SR);
	}
	
	public static Param createRegRegDX() {
		return new Param(SR_DX, null, null, ART_REG_REG_SR);
	}
	
	public static Param createRegOffNum(Constant val, Constant off) {
		return new Param(val, null, off, ART_REG_OFF_NUM);
	}
	
	public static Param createRegOffAX(Constant off) {
		return new Param(SR_AX, null, off, ART_REG_OFF_SR);
	}
	
	public static Param createRegOffBX(Constant off) {
		return new Param(SR_BX, null, off, ART_REG_OFF_SR);
	}
	
	public static Param createRegOffCX(Constant off) {
		return new Param(SR_CX, null, off, ART_REG_OFF_SR);
	}
	
	public static Param createRegOffDX(Constant off) {
		return new Param(SR_DX, null, off, ART_REG_OFF_SR);
	}
	
	public static Param createOffRegNum(Constant val, Constant off) {
		return new Param(val, off, null, ART_OFF_REG_NUM);
	}
	
	public static Param createOffRegAX(Constant off) {
		return new Param(SR_AX, off, null, ART_OFF_REG_SR);
	}
	
	public static Param createOffRegBX(Constant value) {
		return new Param(SR_BX, value, null, ART_OFF_REG_SR);
	}
	
	public static Param createOffRegCX(Constant off) {
		return new Param(SR_CX, off, null, ART_OFF_REG_SR);
	}
	
	public static Param createOffRegDX(Constant off) {
		return new Param(SR_DX, off, null, ART_OFF_REG_SR);
	}
	
	public static Param createOffOffNum(Constant val, Constant off, Constant off0) {
		return new Param(val, off, off0, ART_OFF_OFF_NUM);
	}
	
	public static Param createOffOffAX(Constant off, Constant off0) {
		return new Param(SR_AX, off, off0, ART_OFF_OFF_SR);
	}
	
	public static Param createOffOffBX(Constant off, Constant off0) {
		return new Param(SR_BX, off, off0, ART_OFF_OFF_SR);
	}
	
	public static Param createOffOffCX(Constant off, Constant off0) {
		return new Param(SR_CX, off, off0, ART_OFF_OFF_SR);
	}
	
	public static Param createOffOffDX(Constant off, Constant off0) {
		return new Param(SR_DX, off, off0, ART_OFF_OFF_SR);
	}

	public void checkTwoParam(Map <String, Constant> constants, boolean allowDirectConstant) {
		// TODO Auto-generated method stub
		
	}
	
	public void checkOneParam(Map <String, Constant> constants, boolean allowDirectConstant) {
		// TODO Auto-generated method stub
		
	}
	
	public void checkSmallJmpCall(Map <String, Constant> constants) {
		// TODO Auto-generated method stub
		
	}
	
	public void checkFullRegJmpCall(Map <String, Constant> constants) {
		// TODO Auto-generated method stub
		
	}

}
