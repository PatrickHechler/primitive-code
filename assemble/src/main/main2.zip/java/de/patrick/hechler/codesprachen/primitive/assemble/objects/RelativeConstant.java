package de.patrick.hechler.codesprachen.primitive.assemble.objects;

import java.util.Map;

public class RelativeConstant extends Constant {
	
	private final boolean positive;
	
	public RelativeConstant(boolean positive, String constant) {
		super(constant);
		this.positive = positive;
	}
	
	public RelativeConstant(boolean positive, long value) {
		super(value);
		this.positive = positive;
	}
	
	
	
	@Override
	public long getValue(Map <String, Constant> constants, long position) {
		if (positive) {
			return position + super.getValue(constants, position);
		} else {
			return position - super.getValue(constants, position);
		}
	}
	
	
}
