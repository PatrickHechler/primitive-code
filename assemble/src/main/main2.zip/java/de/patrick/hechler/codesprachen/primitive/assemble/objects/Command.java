package de.patrick.hechler.codesprachen.primitive.assemble.objects;

import java.util.Map;

import de.patrick.hechler.codesprachen.primitive.assemble.enums.Commands;

public class Command {
	
	public final Commands cmd;
	public final Param p1;
	public final Param p2;
	
	public Command(Commands cmd, Param p1, Param p2) {
		this.cmd = cmd;
		this.p1 = p1;
		this.p2 = p2;
	}
	
	public void check(Map<String, Constant> constants) {
		switch(cmd) {
		case CMD_CMP:
			p2.checkTwoParam(constants, true);
			p2.checkTwoParam(constants, true);
			break;
		case CMD_ADD:
		case CMD_AND:
		case CMD_MOV:
		case CMD_MUL:
		case CMD_OR:
		case CMD_SUB:
		case CMD_XOR:
			p2.checkTwoParam(constants, false);
			p2.checkTwoParam(constants, true);
			break;
		case CMD_DIV:
			p2.checkTwoParam(constants, false);
			p2.checkTwoParam(constants, false);
			break;
		case CMD_NEG:
		case CMD_NOT:
		case CMD_POP:
			p1.checkOneParam(constants, false);
			break;
		case CMD_INT:
		case CMD_PUSH:
		case CMD_SET_IP:
			p1.checkOneParam(constants, true);
			break;
		case CMD_IRET:
		case CMD_RET:
			if (p1 != null || p2 != null) {
				throw new IllegalStateException("I can't have params on command <IRET> or <RET> cmd: '"+cmd.name()+"' p1: '"+p1+"' + p2: '"+p2+"'");
			}
			break;
		case CMD_CALL:
		case CMD_CALLEQ:
		case CMD_CALLNE:
		case CMD_CALLGE:
		case CMD_CALLGT:
		case CMD_CALLLE:
		case CMD_CALLLO:
		case CMD_JMP:
		case CMD_JMPEQ:
		case CMD_JMPGE:
		case CMD_JMPGT:
		case CMD_JMPLE:
		case CMD_JMPLO:
		case CMD_JMPNE:
			break;
		case CMD_SCALL:
		case CMD_SCALLEQ:
		case CMD_SCALLNE:
		case CMD_SCALLGE:
		case CMD_SCALLGT:
		case CMD_SCALLLE:
		case CMD_SCALLLO:
		case CMD_SJMP:
		case CMD_SJMPEQ:
		case CMD_SJMPGE:
		case CMD_SJMPGT:
		case CMD_SJMPLE:
		case CMD_SJMPLO:
		case CMD_SJMPNE:
			break;
		}
	}
	
	public static class ConstantPoolCommand extends Command {
		
		public final byte[] bytes;
		
		public ConstantPoolCommand(byte[] bytes) {
			super(null, null, null);
			this.bytes = bytes.clone();
		}
		
		@Override
		public void check(Map <String, Constant> constants) { }
		
	}
	
}
