package de.patrick.hechler.codesprachen.primitive.assemble.objects;

import java.util.Map;

public class Constant {
	
	private final long value;
	private final String constant;
	
	
	
	public Constant(long value) {
		this.value = value;
		this.constant = null;
	}
	
	public Constant(String constant) {
		this.value = 0;
		this.constant = constant;
	}
	
	
	
	public long getValue(Map <String, Constant> constants, long posiotion) {
		if (constant == null) {
			return value;
		}
		Constant zw = constants.get(constant);
		if (zw != null) {
			return zw.getValue(constants, posiotion);
		}
		throw new RuntimeException("the constant '" + constant + "' is unknown in my constant pool: '" + constants + "'");
	}
	
}
