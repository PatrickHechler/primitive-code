package de.patrick.hechler.codesprachen.primitive.assemble.objects;

import java.util.ArrayList;
import java.util.List;

public class ConstantPool {
	
	private List<Object> values = new ArrayList<>();
	
	
	public void addBytes(byte[] bytes) {
		values.add(bytes);
	}
	
	public void addLabel(String name) {
		values.add(name);
	}
	
	public void addConstant(String name) {
		addConstant(new Constant(name));
	}
	
	public void addConstant(Constant cns) {
		values.add(cns);
	}
	
}
